//Trần Thanh Bình làm class ThoiTang
import java.util.Scanner;

public class ThoiTrang extends SanPham {
    private Date thoigianBH;

    public Date getThoigianBH() {
        return thoigianBH;
    }

    public void setThoigianBH(Date thoigianBH) {
        this.thoigianBH = thoigianBH;
    }

    public ThoiTrang(String maSP, String tenSP, double dongiaSP, Date thoigianBH) {
        super(maSP, tenSP, dongiaSP);
        this.thoigianBH = thoigianBH;
    }

    
    public ThoiTrang() {
        super();
        this.thoigianBH = new Date(0, 0, 0);
    }

    public void input() {
        Scanner x=new Scanner(System.in);
        super.input();
        System.out.println("Nhap thoi gian bao hanh: ");
        this.thoigianBH.input();
    }

    public void output() {
        super.output();
        System.out.print("Thoi gian bao hanh: ");
        this.thoigianBH.output();
    }

}
