
import java.util.ArrayList;
import java.util.Scanner;

public class DemonQuanLyBanHang {

    public static void main(String[] args) {
        byte chon;
        Scanner doc = new Scanner(System.in);
        QuanLyBanHang qlbh = new QuanLyBanHang();
        ArrayList<SanPham> sp = new ArrayList<>();
        KhachHang kh = new KhachHang();

        do {
            System.out.println("===== MENU =====");
            System.out.println("1. Them cac mat hang vao danh sach san pham:");
            System.out.println("2. Them khach hang vao danh sach:");
            System.out.println("3. Them san pham vao danh sach mua cua khach hang:");
            System.out.println("4. Tim san pham theo ma san pham:");
            System.out.println("5. Cap nhat don gia san pham:");
            System.out.println("6. Khach hang co so luong san pham nhieu nhat:");
            System.out.println("7. Xuat tong doanh thu:");
            System.out.println("8. Xuat danh sach quan ly ban hang:");
            System.out.println("0. Thoat.");
            System.out.println("================");
            chon = doc.nextByte();
            doc.nextLine();
            switch (chon) {
                case 1:
                //Trần Trọng Trí làm case 1.
                    System.out.println("1.Hang thuc pham, 2 Hang Thoi trang. Hay chon loai hang can nhap:");
                    byte loai = doc.nextByte();
                    doc.nextLine();
                    if (loai == 1) {
                        SanPham s = new ThucPham();
                        s.input();
                        sp.add(s);
                    } else {
                        SanPham s = new ThoiTrang();
                        s.input();
                        sp.add(s);
                    }
                    break;
                case 2:
                //Từ Bá Hưng làm case 2.
                    System.out.println("Nhap khach hang vao danh sach:");

                    kh.input();
                    qlbh.themKhachHang(kh);
                    break;
                case 3:
                //Trần Trọng Trí làm case 3.
                    System.out.println("Nhap ma khach hang: ");
                    String ma = doc.nextLine();
                    System.out.println("Nhap san pham can them vao danh sach mua khach hang: ");
                    String masp = doc.nextLine();
                    boolean isConfirmMasp = false;

                    for (int i = 0; i < sp.size(); i++) {
                        if (masp.equals(sp.get(i).getMaSP())) {
                            qlbh.themSanPham(ma, sp.get(i));
                            isConfirmMasp = true;
                        }
                    }
                    if (!isConfirmMasp) {
                        System.out.println("Ma san pham khong ton tai");
                    }
                    break;
                case 4:
                //Trần Thanh Bình làm case 4.
                    System.out.println("Nhap ma san pham can tim: ");
                    String x = doc.nextLine();
                    for (int i = 0; i < sp.size(); i++) {
                        if (x.equals(sp.get(i).getMaSP())) {
                            sp.get(i).output();
                        }
                    }
                    break;
                case 5:
                //Trần Trọng Trí làm case 5.
                    System.out.println("Nhap ma so san pham thuc pham can doi:");
                    String pham = doc.nextLine();
                    
                    System.out.println("Nhap gia moi cho san pham:");
                    double gia = doc.nextDouble();
                    
                    for (int i = 0; i < sp.size(); i++) {
                        if (pham.equals(sp.get(i).getMaSP())) {
                            qlbh.capNhatDonGiaSP(pham, gia);
                        }
                    }
                    break;
                case 6:
                //Bùi Quốc Bảo làm case 6.
                    qlbh.khachHangMax();
                    break;
                case 7:
                //Nguyễn Nhật Hà làm case 7.
                    System.out.println("Tong doanh thu cua cua hang: " + qlbh.tongDoanhThu());
                    break;
                case 8:
                    qlbh.output();
                    break;
                default:
                    chon = 0;
                    break;
            }
        } while (chon != 0);
    }
}
