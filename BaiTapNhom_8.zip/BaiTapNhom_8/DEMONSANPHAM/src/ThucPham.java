//Nguyễn Nhật Hà làm class ThucPham
public class ThucPham extends SanPham {
    private Date ngaySX;
    private Date ngayHHSD;

    public Date getNgaySX() {
        return ngaySX;
    }

    public void setNgaySX(Date ngaySX) {
        this.ngaySX = ngaySX;
    }

    public Date getNgayHHSD() {
        return ngayHHSD;
    }

    public void setNgayHHSD(Date ngayHHSD) {
        this.ngayHHSD = ngayHHSD;
    }

    public ThucPham(String maSP, String tenSP, double dongiaSP, Date ngaySX, Date ngayHHSD) {
        super(maSP, tenSP, dongiaSP);
        this.ngaySX = ngaySX;
        this.ngayHHSD = ngayHHSD;
    }

    public ThucPham() {
        super();
        this.ngaySX = new Date(0, 0, 0);
        this.ngayHHSD = new Date(0, 0, 0);
    }

    // Tu khoi tao get set va constructor
    public void input() {
        super.input();
        System.out.println("Nhap ngay san xuat: ");
        this.ngaySX.input();
        System.out.println("Nhap ngay het han su dung: ");
        this.ngayHHSD.input();
    }

    public void output() {
        super.output();
        System.out.print("Ngay san xuat: " );
        this.ngaySX.output();
        System.out.print("Ngay het han su dung: ");
        this.ngayHHSD.output();
    }
}
