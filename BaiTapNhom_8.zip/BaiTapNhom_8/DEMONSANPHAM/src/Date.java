//Trần Thanh Bình làm class Date
import java.util.Scanner;

public class Date {
    private int ngay;
    private int thang;
    private int nam;

    
    public Date(int ngay, int thang, int nam) {
        this.ngay = ngay;
        this.thang = thang;
        this.nam = nam;
    }

    public Date(){
        super();
        this.ngay = 0;
        this.thang = 0;
        this.nam = 0;
    }
    
    public int getNgay() {
        return ngay;
    }   

    public void setNgay(int ngay) {
        this.ngay = ngay;
    }

    public int getThang() {
        return thang;
    }
    
    public void setThang(int thang) {
        this.thang = thang;
    }
    
    public int getNam() {
        return nam;
    }
    
    public void setNam(int nam) {
        this.nam = nam;
    }
    
    //Tu khoi tao get set va constructor
    public void input() {
        Scanner x = new Scanner(System.in);
        System.out.println("Nhap ngay: ");
        this.ngay = x.nextInt();
        System.out.println("Nhap thang: ");
        this.thang = x.nextInt();
        System.out.println("Nhap nam:");
        this.nam = x.nextInt();
    }

    public void output() {
        System.out.println(ngay+"/"+thang+"/"+nam);
    }
}
