//Trần Trọng Trí làm class QuanLyBanHang
import java.util.ArrayList;


public class QuanLyBanHang {
    ArrayList<KhachHang> ds = new ArrayList<>();

    public QuanLyBanHang(ArrayList<KhachHang> ds) {
        this.ds = ds;
    }

    public QuanLyBanHang() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ArrayList<KhachHang> getDs() {
        return ds;
    }

    public void setDs(ArrayList<KhachHang> ds) {
        this.ds = ds;
    }
    //Từ Bá Hưng 
    public void themKhachHang(KhachHang kh) {
        ds.add(kh);
    }
    //Trần Trọng Trí
    public void themSanPham(String maKH, SanPham sp) {

        for (KhachHang kh : ds) {
            if (kh.getMaKH().equals(maKH)) {
                kh.getDs().add(sp);
            }
        }
    }
    //Trần Trọng Trí
    public void capNhatDonGiaSP(String maSP, double giaMoi) {
        for (KhachHang kh : ds) {
            for (SanPham sp : kh.getDs()) {
                if (sp.getMaSP().equals(maSP)) {

                    sp.setDongiaSP(giaMoi);

                    // sp.setDongiaSP(giaMoi);
                    System.out.println("Da cap nhat don gia moi cho sam pham co ma so " + maSP + " thanh " + giaMoi);
                    return;
                }
            }
        }
        System.out.println("Khong tim thay san pham co ma " + maSP + " de cap nhat don gia.");
    }
    //Bùi Quốc Bảo
    public void khachHangMax() {
        int max = 0;
        KhachHang khmax = new KhachHang();

        for (KhachHang kh : ds) {
            if (kh.getDs().size() > max) {
                max = kh.getDs().size();
                khmax = kh;
            }
        }
        if (khmax != null) {
            System.out.println("Khach hang co so luong san pham nhieu nhat:");
            khmax.output();
        } else {
            System.out.println("Khong co khach hang nao trong danh sach.");
        }
    }
    //Nguyễn Nhật Hà
    public double tongDoanhThu() {
        double tong = 0;
        for (KhachHang kh : ds) {
            for (SanPham sp : kh.getDs()) {
                tong += sp.getDongiaSP();
            }
        }
        return tong;
    }

    public void output() {
        for (KhachHang kh : ds) {
            System.out.println("Danh sach quan ly ban hang: ");
            kh.output();
        }
    }

}
