//Bùi Quốc Bảo làm class ThucPham
import java.util.Scanner;

public class SanPham {
    private String maSP;
    private String tenSP;
    private double dongiaSP;

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public double getDongiaSP() {
        return dongiaSP;
    }

    public void setDongiaSP(double dongiaSP) {
        this.dongiaSP = dongiaSP;
    }

    public SanPham(String maSP, String tenSP, double dongiaSP) {

        super();
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.dongiaSP = dongiaSP;
    }

    public SanPham() {
        super();
        this.maSP = "";
        this.tenSP = "";
        this.dongiaSP = 0;
    }

    // Tu khoi tao get set va constructor
    public void input() {
        Scanner x = new Scanner(System.in);
        System.out.println("Nhap ma san pham: ");
        this.maSP = x.nextLine();
        System.out.println("Nhap ten san pham: ");
        this.tenSP = x.nextLine();
        System.out.println("Nhap gia san pham: ");
        this.dongiaSP = x.nextDouble();
    }

    public void output() {
        System.out.println(maSP + " - " + tenSP + " - " + dongiaSP);
    }

    
}
