//Từ Bá Hưng làm class KhachHang
import java.util.ArrayList;
import java.util.Scanner;

public class KhachHang {
    private String maKH;
    private String tenKH;
    ArrayList<SanPham> ds = new ArrayList<>();

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public ArrayList<SanPham> getDs() {
        return ds;
    }

    public void setDs(ArrayList<SanPham> ds) {
        this.ds = ds;
    }

    public KhachHang(String maKH, String tenKH, ArrayList<SanPham> ds) {
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.ds = ds;
    }

    public KhachHang() {
        super();
        this.maKH = "";
        this.tenKH = "";
        this.ds = new ArrayList<>();
    }

    public void DanhsachSP(SanPham sp) {
        ds.add(sp);
    }

    public void input() {
        Scanner x = new Scanner(System.in);
        System.out.println("Nhap ma khach hang: ");
        this.maKH = x.nextLine();
        System.out.println("Nhap ten khach hang: ");
        this.tenKH = x.nextLine();
    }

    public void output() {
        System.out.println("Ma khach hang: " + maKH);
        System.out.println("Ten khach hang: " + tenKH);
        System.out.println("Danh sach san pham khach hang:");
        for (int i = 0; i < ds.size(); i++) {
            ds.get(i).output();
        }
    }
}
